import sqlite3
import logging
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackContext

TOKEN = "PUT_NEW_TOKEN_HERE"
ADMIN_ID = 123456789

logging.basicConfig(level=logging.INFO)

conn = sqlite3.connect("ultra_bot.db", check_same_thread=False)
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY,
    balance INTEGER DEFAULT 0,
    referrer INTEGER,
    state TEXT DEFAULT 'none'
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS deposits (
    txn TEXT PRIMARY KEY,
    user_id INTEGER,
    amount INTEGER,
    status TEXT
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS withdrawals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    amount INTEGER,
    status TEXT
)
""")

conn.commit()

def menu():
    return ReplyKeyboardMarkup(
        [["💰 Balance", "📥 Deposit"],
         ["📤 Withdraw", "👥 Referral"],
         ["📊 Dashboard"]],
        resize_keyboard=True
    )

def start(update: Update, context: CallbackContext):
    user_id = update.message.chat_id
    cursor.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
    if not cursor.fetchone():
        ref = int(context.args[0]) if context.args else None
        cursor.execute("INSERT INTO users (user_id, referrer) VALUES (?, ?)", (user_id, ref))
        conn.commit()
        if ref:
            cursor.execute("UPDATE users SET balance = balance + 10 WHERE user_id=?", (ref,))
            conn.commit()
    update.message.reply_text("💳 Welcome to ULTRA PRO Bot", reply_markup=menu())

def balance(update, context):
    user_id = update.message.chat_id
    cursor.execute("SELECT balance FROM users WHERE user_id=?", (user_id,))
    bal = cursor.fetchone()[0]
    update.message.reply_text(f"💰 Balance: {bal} BDT")

def deposit(update, context):
    user_id = update.message.chat_id
    cursor.execute("UPDATE users SET state='await_txn' WHERE user_id=?", (user_id,))
    conn.commit()
    update.message.reply_text("📥 Send TXN ID:")

def withdraw(update, context):
    user_id = update.message.chat_id
    cursor.execute("UPDATE users SET state='await_withdraw' WHERE user_id=?", (user_id,))
    conn.commit()
    update.message.reply_text("📤 Enter amount to withdraw:")

def handle(update: Update, context: CallbackContext):
    user_id = update.message.chat_id
    text = update.message.text

    cursor.execute("SELECT state FROM users WHERE user_id=?", (user_id,))
    state = cursor.fetchone()[0]

    if text == "💰 Balance":
        return balance(update, context)
    elif text == "📥 Deposit":
        return deposit(update, context)
    elif text == "📤 Withdraw":
        return withdraw(update, context)
    elif text == "👥 Referral":
        link = f"https://t.me/YOUR_BOT_USERNAME?start={user_id}"
        return update.message.reply_text(f"🔗 {link}")
    elif text == "📊 Dashboard":
        cursor.execute("SELECT balance FROM users WHERE user_id=?", (user_id,))
        bal = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM users WHERE referrer=?", (user_id,))
        refs = cursor.fetchone()[0]
        return update.message.reply_text(f"📊 Balance: {bal}\n👥 Referrals: {refs}")

    if state == "await_txn":
        txn = text
        cursor.execute("SELECT * FROM deposits WHERE txn=?", (txn,))
        if cursor.fetchone():
            update.message.reply_text("❌ Already used TXN")
            return
        cursor.execute("INSERT INTO deposits VALUES (?, ?, ?, ?)", (txn, user_id, 0, "pending"))
        cursor.execute("UPDATE users SET state='none' WHERE user_id=?", (user_id,))
        conn.commit()
        context.bot.send_message(ADMIN_ID, f"💰 Deposit TXN:\nUser: {user_id}\nTXN: {txn}\n\n/approve {txn} 100")
        update.message.reply_text("⏳ Waiting for admin")
        return

    if state == "await_withdraw":
        try:
            amount = int(text)
            cursor.execute("SELECT balance FROM users WHERE user_id=?", (user_id,))
            bal = cursor.fetchone()[0]
            if amount > bal:
                update.message.reply_text("❌ Not enough balance")
                return
            cursor.execute("INSERT INTO withdrawals (user_id, amount, status) VALUES (?, ?, ?)",
                           (user_id, amount, "pending"))
            cursor.execute("UPDATE users SET state='none' WHERE user_id=?", (user_id,))
            conn.commit()
            context.bot.send_message(ADMIN_ID, f"📤 Withdraw:\nUser: {user_id}\nAmount: {amount}\n\n/pay {user_id} {amount}")
            update.message.reply_text("⏳ Pending withdraw")
        except:
            update.message.reply_text("❌ Enter valid amount")

def approve(update, context):
    if update.message.chat_id != ADMIN_ID:
        return
    txn = context.args[0]
    amount = int(context.args[1])
    cursor.execute("SELECT user_id FROM deposits WHERE txn=?", (txn,))
    data = cursor.fetchone()
    if not data:
        update.message.reply_text("Invalid TXN")
        return
    user_id = data[0]
    cursor.execute("UPDATE users SET balance = balance + ? WHERE user_id=?", (amount, user_id))
    cursor.execute("UPDATE deposits SET status='approved', amount=? WHERE txn=?", (amount, txn))
    conn.commit()
    context.bot.send_message(user_id, f"✅ Deposit: {amount}")

def pay(update, context):
    if update.message.chat_id != ADMIN_ID:
        return
    user_id = int(context.args[0])
    amount = int(context.args[1])
    cursor.execute("UPDATE users SET balance = balance - ? WHERE user_id=?", (amount, user_id))
    cursor.execute("UPDATE withdrawals SET status='paid' WHERE user_id=? AND amount=? AND status='pending'",
                   (user_id, amount))
    conn.commit()
    context.bot.send_message(user_id, f"✅ Withdraw Paid: {amount}")

def main():
    updater = Updater(TOKEN)
    dp = updater.dispatcher
    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CommandHandler("approve", approve))
    dp.add_handler(CommandHandler("pay", pay))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, handle))
    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()
